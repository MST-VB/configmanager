from setuptools import setup
import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setup(
  name='configmanager',         # How you named your configmanager folder (MyLib)
  packages=['configmanager'],   # Chose the same as "name"
  version='0.1',      # Start with a small number and increase it with every change you make
  license='MIT',        # Chose a license from here: https://help.github.com/articles/licensing-a-repository
  description='MAKE CONFIGURATION MANAGEMENT EASIER',   # Give a short description about your library
  long_description=long_description,
  author='Manuel Staufer',                   # Type in your name
  author_email='manuel.staufer@gmail.com',      # Type in your E-Mail
  url='',   # Provide either the link to your github or to your website
  download_url='',    # I explain this later on
  keywords=['CONFIGFILE', 'CONFIGURATION', 'JSON'],   # Keywords that define your configmanager best
  classifiers=[
    'Topic :: Software Development :: Build Tools',
    'License :: OSI Approved :: MIT License',   # Again, pick a license
    'Programming Language :: Python :: 3.8',
  ],
)