**Classes**
    
    Configuration(file_name: str)
        
        getConfig() return the Dictionary
        
        getKey(value) return Key when exist else False
        
        getValue(key) return Value when exist else False
        
        isExist(key) return True when exist else False
        
        setValue(key, value) Add to Configuration or change in the Configuration    
        
**Functions**

    createDirectory("directory_name") create a Directory